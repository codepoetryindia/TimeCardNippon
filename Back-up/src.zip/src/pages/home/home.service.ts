import { Injectable } from '@angular/core';
import { ToastController, LoadingController, AlertController, ModalController } from "ionic-angular";

import { Http } from "@angular/http";
import 'rxjs/Rx';
import { appService } from '../../app/app.service';

@Injectable()
export class HomeService {

    latitude;
    longitude;
    constructor(private _http: Http, private _appservice: appService) { }

    GetTodayPunchedInDetail(EmpCode) {

        return this._http.get(this._appservice.url + "Mobile_Punch_In_Out/GetTodayPunchedInDetail?EmpCode=" + EmpCode, {})
            .map(res => res.json()).toPromise();
    }

    PunchIn(Obj) {
        console.log(Obj);
        return this._http.post(this._appservice.url + "Mobile_Punch_In_Out/PunchIn", Obj, {})
            .map(res => res.json()).toPromise();
    }

    PunchOut(Obj) {
        console.log(Obj);
        return this._http.post(this._appservice.url + "Mobile_Punch_In_Out/PunchOut", Obj, {})
            .map(res => res.json()).toPromise();
    }

}