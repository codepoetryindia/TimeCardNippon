import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { appService } from '../../app/app.service';
import { Storage } from '@ionic/storage'
import { PunchInOutDetailService } from './punch-in-out-detail.service';
/**
 * Generated class for the PunchInOutDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name : 'PunchInOutDetail'
})
@Component({
  selector: 'page-punch-in-out-detail',
  templateUrl: 'punch-in-out-detail.html',
})
export class PunchInOutDetailPage {

  PunchInList : any [];
  EmpCode ;
  TypeOfShit = 'ALL';

  ShowSideMenuIcon ;
 
  constructor(public navCtrl: NavController, public navParams: NavParams,
    private geolocation: Geolocation,
    private menu: MenuController,
    private _storage: Storage,
    private _service : PunchInOutDetailService , 
    public appservice: appService) {
  }

  ionViewWillEnter() {
  this.EmpCode = this.navParams.get("EmpCode");
    console.log(this.EmpCode);

    this.ShowSideMenuIcon = this.navParams.get("ShowMenu");
    
    console.log(this.ShowSideMenuIcon);
    this._service.GetDetailOfTheEmployeePunchIn(this.EmpCode , 1).then((success) => {
      console.log(success);
      this.appservice.dismissLoader();
      
          
      this.PunchInList = success ;
    } , (error)=>{
      this.appservice.dismissLoader();
      
          
      console.log(error);

    });
    
    console.log('ionViewDidLoad PunchInOutDetailPage');
  }

  GetPunchList(Type){
let id = 1;
    if(Type == 'FULL')
    {
      id = 2;
    }
    else if(Type == 'HALF')
    {
      id = 3;
    }
    this._service.GetDetailOfTheEmployeePunchIn(this.EmpCode , id).then((success) => {
      console.log(success);

      this.PunchInList = success ;
    } , (error)=>{

      console.log(error);

    });
  };

  EditPunchIn(data){
    this.appservice.presentLoading();
    console.log(data);
    let obj = {
      data : data
    }
  this.navCtrl.push('EditPunch', obj);
    
  };
}
