import { Injectable } from '@angular/core';
import { ToastController, LoadingController, AlertController, ModalController } from "ionic-angular";

import { Http } from "@angular/http";
import { Observable } from 'rxjs/Rx';
import 'rxjs/Rx';
import { appService } from '../../app/app.service';

@Injectable()
export class PunchInOutSummaryService {

    constructor(private _http: Http, private _appservice: appService) { }



    GetPayRollDetail_WorkingHours(EmpCode) {
        return this._http.get(this._appservice.url + "Mobile_Punch_In_Out/GetPayRollDetail_WorkingHouts?EmpCode=" + EmpCode, {})
            .map(res => res.json()).toPromise();
    }


    getEmployeePunchInSummary(EmpCode) {

        let HoursDetail = this._http.get(this._appservice.url + "Mobile_Punch_In_Out/GetPayRollDetail_WorkingHouts?EmpCode=" + EmpCode, {})
        .map(res => res.json());

        let Summary = this._http.get(this._appservice.url + "Mobile_Report/GetSummaryOfTheEmployee?EmpCode=" + EmpCode, {})
            .map(res => res.json());

        let Halfday = this._http.get(this._appservice.url + "Mobile_Report/GetHalfDayOfTheEmployee?EmpCode=" + EmpCode, {})
            .map(res => res.json());

        let Absent = this._http.get(this._appservice.url + "Mobile_Report/GetAbsentDayOfTheEmployee?EmpCode=" + EmpCode, {})
            .map(res => res.json());

        return Observable.forkJoin([Summary, Halfday, Absent , HoursDetail]).map(res => res).toPromise();
    }


}