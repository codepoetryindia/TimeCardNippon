import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InternationalPunchPage } from './international-punch';

@NgModule({
  declarations: [
    InternationalPunchPage,
  ],
  imports: [
    IonicPageModule.forChild(InternationalPunchPage),
  ],
})
export class InternationalPunchPageModule {}
