import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { appService } from '../../app/app.service';
import { Storage } from '@ionic/storage'
/**
 * Generated class for the InternationalPunchPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "internationalPunch"
})
@Component({
  selector: 'page-international-punch',
  templateUrl: 'international-punch.html',
})
export class InternationalPunchPage {

  constructor(public navCtrl: NavController, public navParams: NavParams,
    private geolocation: Geolocation,
    private menu: MenuController,
    private _storage: Storage,
    public appservice: appService) {
  }

  ionViewWillEnter() {
    this.appservice.dismissLoader();
    console.log('ionViewDidLoad InternationalPunchPage');
  }

}
