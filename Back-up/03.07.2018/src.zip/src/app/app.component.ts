import { Component, ViewChild } from '@angular/core';
import { Platform, Nav, LoadingController, App, MenuController, AlertController } from 'ionic-angular';


import { Geolocation } from '@ionic-native/geolocation';
import { Storage } from '@ionic/storage'
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { appService } from './app.service';

import { Diagnostic } from '@ionic-native/diagnostic';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any;

  pages: Array<{ title: string, component: any }>;

  constructor(public platform: Platform,
    public statusBar: StatusBar,
    public splashScreen: SplashScreen,
    private appservice: appService,
    private geolocation: Geolocation,
    public storage: Storage,
    private menu: MenuController,
    private diagnostic: Diagnostic,
    private app: App) {
    this.initializeApp();

    this.storage.get('UserDetail').then((UserDetail) => {
      console.log(UserDetail);
      if (UserDetail) {
        //    this.storage.remove('UserDetail');

        this.rootPage = 'SercutiryPinPage';

      }
      else {
        this.appservice.IsLoggedInTriggered = true;
        console.log(this.appservice.IsLoggedInTriggered)
        this.rootPage = 'LoginPage';
      }
    });

  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();

      // let successCallback = (isAvailable) => { console.log('Is available? ' + isAvailable); };
      // let errorCallback = (e) => console.error(e);
      
      // this.diagnostic.isLocationEnabled().then((successCallback)=>{
      //   console.log('Is successCallback? ' + successCallback);
      // }).catch(errorCallback);
      
      // // only android
      // this.diagnostic.isGpsLocationEnabled().then(successCallback, errorCallback);

      this.geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }).then((resp) => {
        this.appservice.latitude = resp.coords.latitude;
        this.appservice.longitude = resp.coords.longitude;



      }).catch((error) => {
        console.log(error);
      });

    });



  }


  logout() {

    //clear any cached data
    this.appservice.showConfirm('Are you sure?', 'You want to sign out?').then((res) => {
      if (res) {
        this.appservice.setArray(null);
        this.storage.remove('UserDetail');
        this.menu.close();
        this.menu.enable(false, 'sideMenu');
        this.app.getRootNav().setRoot('LoginPage');

      }
    });

  }



  NavigateToMonthlyReport() {
    this.appservice.presentLoading();
    this.app.getRootNav().popToRoot();

    this.storage.get('UserDetail').then((UserDetail) => {

      let obj = {
        EmpCode: UserDetail.EMP_CODE,
        ShowMenu: true
      }
      this.app.getRootNav().setRoot('PunchInOutSummary', obj);

    });
  }
  NavigateToDailyReport() {
    this.appservice.presentLoading();
    this.app.getRootNav().popToRoot();
    this.app.getRootNav().setRoot('dailyReport');
  }

  NavigateToHomePage() {

    console.log("inside home nav");
    this.appservice.presentLoading();
    this.app.getRootNav().popToRoot();
    this.app.getRootNav().setRoot('HomePage');
  }

  NavigateToDashboard() {
    this.appservice.presentLoading();
    this.app.getRootNav().popToRoot();
    this.app.getRootNav().setRoot('Dashboard');
  }

  MyReports() {
    this.appservice.presentLoading();
    this.storage.get('UserDetail').then((UserDetail) => {

      let obj = {
        EmpCode: UserDetail.EMP_CODE,
        ShowMenu: true
      }

      this.app.getRootNav().popToRoot();
      this.app.getRootNav().setRoot('PunchInOutDetail', obj);

    });
  }

  NavigateToChangePasswordScreen() {
    this.appservice.presentLoading();
    this.app.getRootNav().popToRoot();
    this.app.getRootNav().setRoot('ChangePassword');
  }
  NavigateToChangePinScreen() {
    this.appservice.presentLoading();
    this.app.getRootNav().popToRoot();
    this.app.getRootNav().setRoot('ChangePin');
  };

  
}
